export type WorkExprerience = {
    position: string
    company: string
    province: string
    city: string
    start: string
    end: string
    image?: string
}